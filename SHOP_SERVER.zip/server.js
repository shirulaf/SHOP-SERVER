let express = require('express');  
let app = express();
let bodyParser = require('body-parser');
let Connection = require ('tedious').Connection;
app.use(bodyParser.urlencoded({ extend: false } ));
app.use(bodyParser.json());
let cors = require('cors');
app.use(cors());
let Request = require ('tedious').Request;
let TYPES = require ('tedious').TYPES;
let router = express.Router();
let db = require ('./DButils.js');
let Cart = require('./Cart');
let Mang = require('./Management');
let User = require('./Users');
let Products = require('./Products');
let Pur = require('./Purchase');
let Search = require('./Search');

//check if the user exists ans go to the relevant route

app.use(function (req, res, next) {
	




//-----------------------------------------------------

	console.log (req.body); 
	
	
		let CookieID = req.body.CookieID;
		if (!CookieID)
			{
				console.log("no cookie");
				req.exist=false;
				next('route');
				return;
			}
			

				let query = "select * From Login where UserID= '"  + (+CookieID) + "' and cookies ='true'";
				console.log ( query ) ;
			
				db.Select ( query)
				.then (function (result){
					if (result.length==1)
						{
							console.log(result);
							req.uID= result[0].userID;
							req.exist=true;

						}
					else
						req.exist=false;
				next('route');
				})
				.catch(function (error) {
		  	          console.log(error.message);
		  	          res.sendStatus(400);
		        });
			
			
		
		
});



		


//-------------------------------------------------------------------
//-------------------------------------------------------------------

  let server = app.listen(8000, function () {  
  let host = server.address().address  
  let port = server.address().port  
  app.use('/', router);
  app.use('/Cart', Cart);
  app.use('/Management', Mang);
  app.use('/Users', User);
  app.use('/Purchase', Pur);
  app.use('/Products',Products);
  app.use('/Search' ,Search);
 

  console.log("Example app listening at http://%s:%s", host, port) ;
}) ;